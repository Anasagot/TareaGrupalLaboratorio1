﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un carácter: ");
            char caracter = Console.ReadKey().KeyChar; 
            Console.WriteLine();


            char caracterMin = char.ToLower(caracter);


            if (caracterMin == 'a' || caracterMin == 'e' || caracterMin == 'i' || caracterMin == 'o' || caracterMin == 'u')
            {
                Console.WriteLine("El carácter ingresado es una Vocal. ");
            }
            else
            {
                Console.WriteLine("El carácter ingresado No es Vocal. ");
            }


            Console.WriteLine("Presione cualquier tecla para salir. ");
            Console.ReadKey();

            Console.ReadLine(); 
        }
    }
}
