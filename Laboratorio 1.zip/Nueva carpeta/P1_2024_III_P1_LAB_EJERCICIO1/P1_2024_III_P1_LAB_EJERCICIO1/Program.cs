﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //solicitar la cantidad de la compra de camisetas y definir que descuento se le otorgara al cliente.
            const int preciocamiseta = 100;
            Console.WriteLine("ingrese la cantidad de camisas que comprara: ");
            int cantidadcamisas = int.Parse(Console.ReadLine());

            double descuento = 0;

            if (cantidadcamisas == 10)
            { descuento = 0.10;
            }
            else if (cantidadcamisas == 20)
            {
                descuento = 0.20;
            }
            else if (cantidadcamisas == 30)
            {
                descuento = 0.40;
            }

            double totalsindescuento = cantidadcamisas * preciocamiseta;
            double totalcondescuento = totalsindescuento -(totalsindescuento * descuento);

            Console.WriteLine("Descripción de la Compra:");
            Console.WriteLine($"Cantidad de camisas compradas: {cantidadcamisas} ");
            Console.WriteLine($"Precio sin descuento: {totalsindescuento} ");
            Console.WriteLine($"Descuento otorgado por la compra: {descuento * 100}% ");
            Console.WriteLine($"Total a pagar:{totalcondescuento} ");
            Console.ReadLine();

        }
    }
}
