﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO10
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double Centigrados(double fahrenheit)
            {
                return (fahrenheit - 32) * 5 / 9;
            }

            double Fahrenheit(double centigrados)
            {
                return (centigrados * 9 / 5) + 32;
            }

            {
                Console.WriteLine("Tabla de conversión de Celsius a Fahrenheit (0°C - 100°C) :");
                Console.WriteLine("Celsius Fahrenheit ");

                for (int celsius = 0; celsius <= 100; celsius++)
                {
                    double fahrenheit = Fahrenheit(celsius);
                    Console.WriteLine($"{celsius}\t\t{fahrenheit:F2} ");
                }

                Console.WriteLine("Tabla de conversión de Fahrenheit a Celsius (32°F - 212°F) :");
                Console.WriteLine("Fahrenheit Celsius ");

                for (int fahrenheit = 32; fahrenheit <= 212; fahrenheit++)
                {
                    double celsius = Centigrados(fahrenheit);
                    Console.WriteLine($"{fahrenheit} {celsius:F2} ");
                    Console.ReadLine();

                }
            }
        }
    }
} 
