﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Desarrollar una aplicacion que determine el limite de credito de los clientes de una tienda.

            int numerocuenta;
            double saldoinicial;
            double totalcargado;
            double totalcredito;
            double limitecredito;
            string continuar;

            do
            {
                Console.WriteLine("Ingrese numero de cuenta del cliente: ");
                numerocuenta = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el saldo inicial del cliente: ");
                saldoinicial = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese los articulos cargados: ");
                totalcargado = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el total del credito: ");
                totalcredito = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el limite de credito autorizado: ");
                limitecredito = double.Parse(Console.ReadLine());

                double nuevosaldo = saldoinicial + totalcargado - totalcredito;

                if (nuevosaldo == limitecredito)
                {
                    Console.WriteLine("Alerta por credito Excedido: ");
                    Console.WriteLine($"Numero de cuenta: {numerocuenta} ");
                    Console.WriteLine($"Limite de credito: {limitecredito} ");
                    Console.WriteLine($"Nuevo saldo: {nuevosaldo} ");
                    Console.WriteLine("El ciente Exedio su limite de credito: ");
                }
                else
                {
                    Console.WriteLine("El saldo esta dentro del limite del credito autorizado: ");
                }
                Console.WriteLine("¿Requiere ingresar otro cliente?: ");
                continuar = Console.ReadLine();
            } while ( continuar == "si" );

            Console.WriteLine("Hasta pronto: ");
            Console.ReadLine();
        }
    }
}
