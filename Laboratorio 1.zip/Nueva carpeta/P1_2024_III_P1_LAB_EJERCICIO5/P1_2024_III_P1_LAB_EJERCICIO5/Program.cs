﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Realizar un programa que diga las cantidades de cifras si es mayor o menor a 0 y menor a 10.
            // De lo contrario que muestre que es mayor a 5

            Console.WriteLine("Ingrese un numero: ");

            int numero = int.Parse(Console.ReadLine());

            if ((numero > 0) && (numero < 10))

            {
                Console.WriteLine("El numero tiene 1 cifra. ");
            }

            else if ((numero >= 10) && (numero < 100))
            {
                Console.WriteLine("El numero tiene dos cifras. ");
            }
            else if ((numero >= 100) && (numero < 1000))
            {
                Console.WriteLine("El numero tiene 3 cifras. ");
            }
            else if ((numero >= 1000) && (numero < 10000))
            {
                Console.WriteLine("El numero tiene 4 cifras. ");
            }
            else
            {
                Console.WriteLine("El numero descrito tine 5 cifras. ");
            }

            Console.ReadLine();
        }

        
    }
}
