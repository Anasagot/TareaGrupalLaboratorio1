﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Crear un programa que determine el sueldo bruto por empleado.

            string continuar;

            do
            {
                Console.WriteLine("Ingrese el nombre del empleado ");
                string nombreempleado = Console.ReadLine();
                Console.WriteLine("Ingrese el detalle de horas trabajadas de la semana pasada ");
                double horastrabajadas = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el valor por hora del empleado ");
                double valorhora = double.Parse(Console.ReadLine());

                double sueldobruto = 0;
                double horasnormales = 40;
                double horasextras = 0;

                if (horastrabajadas > horasnormales)
                {
                    horasextras = horastrabajadas - horasnormales;
                    sueldobruto = (horasnormales * valorhora) + (horasextras * valorhora);
                }
                else
                {
                    sueldobruto = horastrabajadas * valorhora;
                }

                Console.WriteLine($"Nombre de empleado: {nombreempleado} ");
                Console.WriteLine($"Horas trabajadas: {horastrabajadas} ");
                Console.WriteLine($"Valor por hora: {valorhora}");
                Console.WriteLine($"Sueldo bruto: {sueldobruto}");

                Console.WriteLine("¿Prefiere ingresar un nuevo empleado? (si/no): ");
                continuar = Console.ReadLine().ToLower();
            } while (continuar == "si");
            Console.WriteLine("Hasta pronto. ");
            Console.ReadLine();
        }
    }
}
