﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double nota1, nota2, nota3, promedio;

            Console.WriteLine("Ingrese la primera nota: ");
            nota1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese la segunda nota: ");
            nota2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese la tercera nota: ");
            nota3 = Convert.ToDouble(Console.ReadLine());

            promedio = (nota1 + nota2 + nota3) / 3;
  
            int rango;
 
            if (promedio < 0 || promedio > 100)
            {
                rango = 5;
            }
            else if (promedio < 70)
            {
                rango = 1; 
            }
            else if (promedio <= 80)
            {
                rango = 2;
            }
            else if (promedio <= 90)
            {
                rango = 3; 
            }
            else
            {
                rango = 4;
            }
 
            switch (rango)
            {
                case 1:
                    Console.WriteLine("Calificación: Reprueba ");
                    break;
                case 2: 
                    Console.WriteLine("Calificación: Bueno ");
                    break;
                case 3:
                    Console.WriteLine("Calificación: Muy Bueno ");
                    break;
                case 4:
                    Console.WriteLine("Calificación: Sobresaliente ");
                    break;
                case 5:
                    Console.WriteLine("Error: Promedio fuera de rango (0-100) ");
                    break;
                default:
                    Console.WriteLine("Caso no gestionado. ");
                    break;
            }

            Console.WriteLine("Presione una tecla para salir...");
            Console.ReadKey();

            Console.ReadLine();
        }
    }
}
