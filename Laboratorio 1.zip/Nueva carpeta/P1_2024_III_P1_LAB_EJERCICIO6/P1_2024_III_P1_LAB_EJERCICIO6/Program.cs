﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Crear un programa donde un almacen de pedidios por correo, hacer que describa la serie de pares de numeros.
            {
                double totalVenta = 0.0;
                int producto, cantidad;

                while (true)
                {

                    Console.WriteLine("Ingrese el numero del producto: ");
                    producto = Convert.ToInt32(Console.ReadLine());

                    if (producto == 0)
                    {
                        break;
                    }

                    Console.WriteLine("Ingrese la cantidad vendida: ");
                    cantidad = Convert.ToInt32(Console.ReadLine());

                    double precio;

                    switch (producto)
                    {
                        case 1:
                            precio = 2.98;
                            break;
                        case 2:
                            precio = 4.50;
                            break;
                        case 3:
                            precio = 9.98;
                            break;
                        case 4:
                            precio = 4.49;
                            break;
                        case 5:
                            precio = 6.87;
                            break;
                        default:
                            Console.WriteLine("Producto no válido. Por favor, ingrese un número de producto entre 1 y 5.");
                            continue; 
                    }
 
                    double totalProducto = precio * cantidad;
                    totalVenta += totalProducto;
                    Console.WriteLine($"Precio del producto: ${precio:F2}, Cantidad vendida: {cantidad}, Total: ${totalProducto:F2}");
                }

                Console.WriteLine($"El total de ventas es: ${totalVenta:F2}");
                Console.ReadLine();
            }
        }
    }
}