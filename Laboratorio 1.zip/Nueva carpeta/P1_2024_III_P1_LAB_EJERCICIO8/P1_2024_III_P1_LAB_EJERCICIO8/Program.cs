﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double cuotaBase = 2.00;
            const double cuotaAdicionalPorHora = 0.50; 
            const double cargoMaximo = 10.00;    

            double totalGeneral = 0.00;
             
            Console.WriteLine("Cálculo de cargos por estacionamiento ");
            Console.WriteLine("-_____________________________________");
            Console.WriteLine("| Cliente | Horas | Cargo            |");
            Console.WriteLine("______________________________________");


            for (int i = 1; i <= 3; i++)
            {
                Console.Write($"Ingrese las horas estacionadas para el cliente {i}: ");
                double horas = Convert.ToDouble(Console.ReadLine());
                double cargo = calcularCargos(horas, cuotaBase, cuotaAdicionalPorHora, cargoMaximo);
                totalGeneral += cargo;

 
                Console.WriteLine($"| {i,7} | {horas,5} | {cargo,15:C} |");
            }

            Console.WriteLine($"Total de los recibos de ayer: {totalGeneral:C} ");
        }

        static double calcularCargos(double horas, double cuotaBase, double cuotaAdicional, double cargoMaximo)
        {
            if (horas <= 3)
            {
                return cuotaBase;
            }
            else
            {

                double horasAdicionales = Math.Ceiling(horas - 3);
                double cargo = cuotaBase + (horasAdicionales * cuotaAdicional);

                return cargo > cargoMaximo ? cargoMaximo : cargo;
                Console.ReadLine();
        }  }
    }
}
