﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int numeroSecreto = random.Next(1, 1001);

            int intento = 0;
            int numeroIngresado;

            Console.WriteLine("Bienvenido al juego Adivina el Numero" );
            Console.WriteLine("Seleccionado un número entre 1 y 1000." );

            do
            {
                Console.WriteLine("Ingresa tu numero: ");
                if (!int.TryParse(Console.ReadLine(), out numeroIngresado))
                {
                    Console.WriteLine("Por favor ingresa un numero entero valido." );
                    continue;
                }

                intento++;

                if (numeroIngresado < numeroSecreto)
                {
                    Console.WriteLine("Demasiado bajo.");
                }
                else if (numeroIngresado > numeroSecreto)
                {
                    Console.WriteLine("Demasiado alto.");
                }
                else
                {
                    Console.WriteLine($"Excelente! ¡Adivinaste el número en {intento} intentos" );
                    break;
                }
            } while (true);
            Console.ReadLine();
        }
    }
}
