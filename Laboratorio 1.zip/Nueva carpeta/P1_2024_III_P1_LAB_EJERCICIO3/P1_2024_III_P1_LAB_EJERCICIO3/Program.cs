﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Realizar un programa para facturar en una panaderia, identificando que tipo de cliente y membresía.
            double totalcompra;
            string tipomembresia;
            double descuento = 0;

            Console.WriteLine("Digite el total de la compra: ");
            totalcompra = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite el tipo de membresia (A, B, C): ");
            tipomembresia = Console.ReadLine(); 

            switch (tipomembresia)
            {
                case "A":
                    descuento = 0.10;
                    break;
                    case "B":
                    descuento = 0.15;
                    break;
                    case "C":
                    descuento = 0.20;
                    break;
                    default:
                    Console.WriteLine("Membresia no valida, no aplica descuentos: ");
                    break;
            }
            double totalcondescuento = totalcompra - (totalcompra * descuento);

            Console.WriteLine($"Total de la compra: {totalcompra} ");
            if (descuento > 0)
            {
                Console.WriteLine($"Aplicar descuento: {descuento * 100}% ");
                Console.WriteLine($"Total a pagar con descuento aplicado: {totalcondescuento} ");
            }
            else
            {
                Console.WriteLine("Total a pagar: ");
            }
            Console.ReadLine();

        }
    }
}
