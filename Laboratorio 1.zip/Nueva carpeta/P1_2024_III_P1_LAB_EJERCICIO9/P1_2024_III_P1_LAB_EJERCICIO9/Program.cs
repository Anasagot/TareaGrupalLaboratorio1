﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_2024_III_P1_LAB_EJERCICIO9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su salario: ");
            double salario = Convert.ToDouble(Console.ReadLine());

            double aumento = CalcularAumento(salario);
            double nuevoSalario = salario + aumento;

            Console.WriteLine($"Salario original: {salario:C} ");
            Console.WriteLine($"Aumento: {aumento:C}");
            Console.WriteLine($"Nuevo salario: {nuevoSalario:C} ");
        }

        static double CalcularAumento(double salario)
        {
            double aumento;

            if (salario < 5000)
            {
                aumento = salario * 0.20; 
            }
            else if (salario < 10000)
            {
                aumento = salario * 0.10; 
            }
            else if (salario < 15000)
            {
                aumento = salario * 0.05;
            }
            else
            {
                aumento = salario * 0.03; 
            }

            return aumento;

            Console.ReadLine();
        }
    }
}
